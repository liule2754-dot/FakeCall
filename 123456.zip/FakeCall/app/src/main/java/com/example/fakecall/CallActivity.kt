package com.example.fakecall

import android.app.Activity
import android.app.NotificationManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import android.view.Gravity
import android.widget.*

class CallActivity : Activity() {
    private var ring: Ringtone? = null
    private var vib: Vibrator? = null
    private val h = Handler(Looper.getMainLooper())
    private var sec = 0
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        getSystemService(NotificationManager::class.java).cancel(1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(110), dp(20), dp(56))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF12101C.toInt(), 0xFF3A1420.toInt(), 0xFF05060A.toInt()))
        }
        fun tv(t: String, s: Float) = TextView(this).apply { text = t; textSize = s; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        root.addView(tv(intent.getStringExtra("n") ?: "未知来电", 30f))
        root.addView(tv(intent.getStringExtra("p") ?: "", 20f).apply { setPadding(0, dp(10), 0, 0) })
        val state = tv("来电", 18f).apply { setPadding(0, dp(40), 0, 0) }; root.addView(state)
        root.addView(Space(this), LinearLayout.LayoutParams(0, 0, 1f))
        fun circle(c: Int, t: String, onClick: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(Button(this@CallActivity).apply {
                text = "✆"; textSize = 30f; setTextColor(Color.WHITE)
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
                if (c == 0xFFEF4136.toInt()) rotation = 135f
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(dp(80), dp(80)))
            addView(tv(t, 14f).apply { setPadding(0, dp(12), 0, 0) })
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; weightSum = 2f }
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        val decline = circle(0xFFEF4136.toInt(), "拒接") { finish() }
        val accept = circle(0xFF14B829.toInt(), "接听") {
            stopRing(); state.text = "00:00"; row.removeAllViews()
            row.addView(circle(0xFFEF4136.toInt(), "挂断") { finish() }, LinearLayout.LayoutParams(0, -2, 2f))
            h.post(object : Runnable { override fun run() { sec++; state.text = "%02d:%02d".format(sec / 60, sec % 60); h.postDelayed(this, 1000) } })
        }
        row.addView(decline, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(accept, LinearLayout.LayoutParams(0, -2, 1f))
        setContentView(root)
        ring = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))?.apply { isLooping = true; play() }
        vib = getSystemService(Vibrator::class.java)
        vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
        h.postDelayed({ if (sec == 0) finish() }, 45000)
    }

    private fun stopRing() { ring?.stop(); vib?.cancel() }
    override fun onDestroy() { stopRing(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}
