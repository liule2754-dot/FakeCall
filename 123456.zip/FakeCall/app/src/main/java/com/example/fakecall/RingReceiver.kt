package com.example.fakecall

import android.app.*
import android.content.*

class RingReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("call", "来电", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        val ai = Intent(c, CallActivity::class.java).putExtras(i).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(c, 1, ai, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, "call").setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(i.getStringExtra("n")).setContentText("来电").setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(pi, true).setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(1, n)
    }
}
