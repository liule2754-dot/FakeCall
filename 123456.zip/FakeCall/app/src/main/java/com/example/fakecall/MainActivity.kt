package com.example.fakecall

import android.Manifest
import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private var delay = 0
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("p", 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(56), dp(22), dp(22)); setBackgroundColor(0xFF0E141B.toInt())
        }
        fun label(t: String) = TextView(this).apply { text = t; setTextColor(0xFF8FA0B0.toInt()); textSize = 14f; setPadding(0, dp(20), 0, dp(8)) }
        fun field(v: String, num: Boolean) = EditText(this).apply {
            setText(v); setTextColor(Color.WHITE); textSize = 20f; background = bg(0xFF17212B.toInt(), 18)
            setPadding(dp(20), dp(16), dp(20), dp(16)); setSingleLine()
            if (num) inputType = InputType.TYPE_CLASS_PHONE
        }
        root.addView(TextView(this).apply { text = "给自己一通来电"; setTextColor(Color.WHITE); textSize = 32f })
        root.addView(TextView(this).apply { text = "设定来电人，在需要的时刻响起。"; setTextColor(0xFF8FA0B0.toInt()); textSize = 16f })
        root.addView(label("来电姓名")); val name = field(sp.getString("n", "神秘来电")!!, false); root.addView(name)
        root.addView(label("显示号码")); val num = field(sp.getString("p", "18888888888")!!, true); root.addView(num)
        root.addView(label("多久后响铃"))
        val labels = listOf("立即", "10秒", "30秒", "1分", "5分"); val secs = listOf(0, 10, 30, 60, 300)
        val row = LinearLayout(this); val chips = ArrayList<Button>()
        fun paint() = chips.forEachIndexed { i, c ->
            val on = secs[i] == delay
            c.background = bg(if (on) 0xFF6FE3C1.toInt() else 0xFF17212B.toInt(), 16)
            c.setTextColor(if (on) 0xFF05211A.toInt() else Color.WHITE)
        }
        labels.forEachIndexed { i, t ->
            val c = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { delay = secs[i]; paint() } }
            chips.add(c); row.addView(c, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        paint(); root.addView(row)
        val go = Button(this).apply {
            text = "开始来电"; textSize = 18f; setTextColor(0xFF05211A.toInt()); background = bg(0xFF6FE3C1.toInt(), 20)
        }
        root.addView(go, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(32) })
        root.addView(TextView(this).apply {
            text = "vivo 手机请到 设置 > 应用与权限 > 权限管理，给本应用开启“后台弹出界面”和“自启动”，并在电池里选“允许后台高耗电”。点这里打开应用设置。"
            setTextColor(0xFF8FA0B0.toInt()); textSize = 13f; setPadding(0, dp(24), 0, 0)
            setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        })
        go.setOnClickListener {
            sp.edit().putString("n", name.text.toString()).putString("p", num.text.toString()).apply()
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            val nm = getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent())
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            val i = Intent(this, RingReceiver::class.java).putExtra("n", name.text.toString()).putExtra("p", num.text.toString())
            if (delay == 0) { startActivity(Intent(this, CallActivity::class.java).putExtras(i)); return@setOnClickListener }
            val pi = PendingIntent.getBroadcast(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = getSystemService(AlarmManager::class.java)
            val t = System.currentTimeMillis() + delay * 1000L
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            Toast.makeText(this, "已设定，可以锁屏等待", Toast.LENGTH_SHORT).show()
        }
        setContentView(root)
    }
}
